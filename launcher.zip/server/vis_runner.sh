python3 launcher.pyz visualizer -skip
