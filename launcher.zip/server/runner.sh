python3 launcher.pyz generate
python3 launcher.pyz run -q
